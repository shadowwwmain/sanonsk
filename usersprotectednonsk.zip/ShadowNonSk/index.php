<?php
session_start();

if (isset($_POST['uname']) && isset($_POST['password'])) {

    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $uname = validate($_POST['uname']);
    $pass = validate($_POST['password']);

    if (empty($uname)) {
        header("Location: index.php?error=User Name is required");
        exit();
    } elseif (empty($pass)) {
        header("Location: index.php?error=Password is required");
        exit();
    } else {
        // Read the JSON file
        $jsonString = file_get_contents('./users/users.json');

        // Convert JSON string to PHP array
        $users = json_decode($jsonString, true);

        $matchedUser = null;

        // Search for a matching user
        foreach ($users as $user) {
            if ($user['user_name'] === $uname && $user['password'] === $pass) {
                $matchedUser = $user;
                break;
            }
        }

        if ($matchedUser) {
            $_SESSION['user_name'] = $matchedUser['user_name'];
            $_SESSION['name'] = $matchedUser['name'];
            $_SESSION['id'] = $matchedUser['id'];
            header("Location: home.php");
            exit();
        } else {
            echo "Incorrect User name or password";
        }
    }
} else {
    ?>

    <!DOCTYPE html>
    <html>
    <head>
        <title>Login</title>
        <style>
            body {
                background-color: #333333;
                color: white;
                font-family: Arial, sans-serif;
            }
            
            h2 {
                text-align: center;
            }
            
            .error {
                color: red;
            }
            
            .login-form {
                display: flex;
                flex-direction: column;
                align-items: center;
                margin-top: 100px;
            }
            
            .login-form label {
                margin-bottom: 10px;
            }
            
            .login-form input[type="text"],
            .login-form input[type="password"] {
                width: 250px;
                padding: 10px;
                border-radius: 5px;
                border: none;
                background-color: #ffffff;
            }
            
            .login-form input[type="submit"] {
                width: 150px;
                padding: 10px;
                border-radius: 5px;
                border: none;
                background-color: #333333;
                color: white;
                cursor: pointer;
                transition: transform 0.3s;
            }
            
            .login-form input[type="submit"]:hover {
                transform: scale(1.1);
            }
        </style>
    </head>
    <body>
        <h2>Login</h2>
        <?php
        if (isset($_GET['error'])) {
            echo "<p class='error'>" . $_GET['error'] . "</p>";
        }
        ?>
        <form class="login-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="uname">Username:</label>
            <input type="text" id="uname" name="uname" required><br><br>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br><br>
            
                        <input type="submit" value="Login">
        </form>

      <footer style="display: flex;
                flex-direction: column;
                align-items: center; margin-top: 100px;">Login system by Shadow</footer>
    </body>
    </html>

    <?php
}
?>
